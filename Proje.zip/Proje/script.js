const form = document.getElementById('user-form');
const message = document.getElementById('message');
const peopleList = document.getElementById('people-list');

form.addEventListener('submit', function (e) {
  e.preventDefault();
  message.textContent = '';

  const name = document.getElementById('full-name').value.trim();
  const email = document.getElementById('email').value.trim();
  const age = parseInt(document.getElementById('age').value);

  if (!validateField('Full Name', name) || !validateEmail(email) || !validateAge(age)) {
    return;
  }

  if (age > 18) {
    const person = { name, email, age };
    addPersonToList(person);
    form.reset();
  } else {
    message.textContent = 'You must be over 18 to submit';
  }
});

function validateField(fieldName, value) {
  if (!value) {
    message.textContent = `${fieldName} is required.`;
    return false;
  }
  return true;
}

function validateEmail(email) {
  const regex = /^\S+@\S+\.\S+$/;
  if (!regex.test(email)) {
    message.textContent = 'Invalid email format.';
    return false;
  }
  return true;
}

function validateAge(age) {
  if (isNaN(age) || age <= 0) {
    message.textContent = 'Age must be a number greater than 0.';
    return false;
  }
  return true;
}

function addPersonToList(person) {
  const li = document.createElement('li');
  li.textContent = `Full Name: ${person.name}, Email: ${person.email}, Age: ${person.age}`;
  peopleList.appendChild(li);
}
